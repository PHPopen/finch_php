﻿<?php
class index_controller extends controller{
	public function index(){
		//$this->view('index.html');
	}
}
?>