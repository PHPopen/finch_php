<?php if (!defined('BASE_PATH')) exit;?>﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PHP利用smtp类发送邮件范例</title>
</head>
<body>
<form action="/default/comm/send_mail" method="post">
	<p>标&nbsp;&nbsp;题：<input type="text" name="u_title" /></p>
	<p>内&nbsp;&nbsp;容：<textarea name="u_content" cols="50" rows="5"></textarea></p>
	<p><input type="submit" value="发送"  /></p>
</form>
</body>
</html>
